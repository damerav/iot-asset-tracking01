# 🔖 Release v1.0.0 – IoT Asset Tracking Platform

## ✨ New Features
- ✅ Realtime telemetry dashboard with Recharts
- ✅ Interactive map view using Leaflet with asset alerts
- ✅ Authenticated UI with JWT and protected routes
- ✅ Backend KPIs for asset status, uptime, and health
- ✅ Docker Compose for full local environment

## 🧪 Test Coverage
- ✅ Unit tests (Jest) for backend controllers
- ✅ Cypress E2E tests for login and dashboard
- ✅ React Testing Library for UI component validation

## 📦 Release Artifacts
- [`release_checklist.md`](./docs/release_checklist.md)
- [`release_checklist.csv`](./release_checklist.csv)
- Source: [`iot-asset-tracking-release-v1.0.0.zip`](./iot-asset-tracking-release-v1.0.0.zip)

## 🚀 Deployment Targets
- 🟢 Local via `docker-compose up`
- 🟢 QA Mode via EC2 + DynamoDB
- 🟢 Frontend deploy-ready to Netlify or Vercel

## 🔧 How to Upgrade
```bash
npm install && npm run dev
```
Update your `.env` file and run data seeders:
```bash
node scripts/generateAssetData.js
node scripts/generateTelemetryData.js
```

## 📣 Notes
This marks our stable MVP milestone. Monitoring hooks and CI/CD are ready for scale.

---
Let us know in Issues if you need multi-tenant, GraphQL, or mobile offline support next!
