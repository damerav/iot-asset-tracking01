# 🛡️ Security Policy

## Supported Versions
We actively support the following versions:

| Version | Supported          |
|---------|--------------------|
| 1.0.x   | ✅ Yes (latest)     |
| < 1.0   | ❌ No               |

---

## 🔐 Reporting a Vulnerability
If you discover a security vulnerability:

1. **Do not open a public issue.**
2. Instead, email us directly at: `security@iotconnect.io`
3. Please include:
   - Description of the issue
   - Steps to reproduce (if applicable)
   - Impact assessment or severity

We will review your report promptly and keep your disclosure confidential.

---

## 🛠 Patching Process
1. Report is acknowledged within **48 hours**
2. Investigation and fix are prioritized by severity
3. Patch is published and noted in the next release changelog
4. CVE may be assigned if appropriate

---

## 📜 Disclosure Policy
We follow responsible disclosure standards. Coordinated public disclosure happens **after** a fix is released and verified.

Thank you for helping secure the IoT ecosystem! 🔒
