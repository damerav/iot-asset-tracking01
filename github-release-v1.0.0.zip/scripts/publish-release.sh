#!/bin/bash

TAG=v1.0.0
TITLE="🔖 IoT Asset Tracking $TAG"
REPO="$(basename `git rev-parse --show-toplevel`)"

if ! command -v gh &> /dev/null; then
  echo "❌ GitHub CLI (gh) not found. Please install it first."
  exit 1
fi

# Confirm files exist
for FILE in RELEASE_NOTES.md release_checklist.md release_checklist.csv; do
  if [ ! -f "$FILE" ]; then
    echo "❌ Missing $FILE. Please ensure all release files are in place."
    exit 1
  fi
done

# Create release
gh release create $TAG \
  release_checklist.md \
  release_checklist.csv \
  iot-asset-tracking-release-$TAG.zip \
  --title "$TITLE" \
  --notes-file RELEASE_NOTES.md

echo "✅ GitHub release $TAG published with notes and artifacts."
