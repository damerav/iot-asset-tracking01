# 🤝 Contributing to IoT Asset Tracking

Thanks for helping improve this project! 🎉 Here’s how you can contribute:

---

## 🛠 Set Up Your Dev Environment
1. Fork the repo and clone your fork:
   ```bash
   git clone https://github.com/YOUR-USERNAME/iot-asset-tracking.git
   cd iot-asset-tracking
   ```
2. Install dependencies:
   ```bash
   make install
   ```
3. Run the app:
   ```bash
   make run
   ```

---

## 💡 What Can You Contribute?
- Bug fixes / performance improvements
- Frontend UI polish
- Accessibility enhancements
- Writing/updating tests (Jest, Cypress)
- CI/CD improvements
- Docs and translations

---

## ✅ Contribution Checklist
- [ ] Code is formatted (`npm run lint`)
- [ ] New components or functions are tested
- [ ] No breaking changes without backward compatibility
- [ ] Update `README.md` or `CHANGELOG.md` if needed

---

## 🔀 Submitting a PR
1. Create a new branch:
   ```bash
   git checkout -b feature/my-new-feature
   ```
2. Push your changes:
   ```bash
   git push origin feature/my-new-feature
   ```
3. Open a PR against the `main` branch

Please use conventional commit messages (e.g., `feat: add telemetry filter`, `fix: resolve chart tooltip bug`).

---

## 👥 Community
Feel free to discuss ideas or bugs in [GitHub Issues](../../issues).

Happy contributing! 🚀
