# ✅ IoT Asset Tracking – Release Checklist

## 🧱 Code Quality
- [ ] All unit tests (Jest) pass (`npm test` in backend)
- [ ] All E2E tests (Cypress) pass (`npm run cypress` in frontend)
- [ ] All linting warnings resolved (`npm run lint` in frontend)
- [ ] Code reviewed and approved (via PR checklist)

## 📦 Versioning & Docs
- [ ] Bump `version.txt` and `package.json` versions
- [ ] Update `changelog.md` with new features and fixes
- [ ] Ensure OpenAPI `openapi-spec.yaml` is up to date
- [ ] Push to `main` branch with commit message: `🔖 Release vX.X.X`

## 🚀 Build & Deployment
- [ ] Run `docker-compose up --build` to confirm local image stability
- [ ] Zip release folder (`release-vX.X.X.zip`) with:
  - Source code
  - README + env samples
  - Build artifacts (if any)
- [ ] Tag release on GitHub: `vX.X.X`
- [ ] Deploy to:
  - [ ] EC2 / PM2 (QA / Prod)
  - [ ] Netlify / Vercel (Frontend)
  - [ ] DynamoDB mode tested (QA only)

## 📊 Post-Release
- [ ] Run smoke tests on dashboard and KPI charts
- [ ] Monitor CloudWatch / logs / Sentry (if integrated)
- [ ] Validate asset sync + telemetry freshness
- [ ] Send release email/update to stakeholders

---
🟢 Status: _Ready to release pending version bump and tag_
